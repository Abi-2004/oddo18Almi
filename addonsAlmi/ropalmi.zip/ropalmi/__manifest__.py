{
    'name': 'ROPALMI - Clothing Shop Management',
    'version': '1.0',
    'author': 'Your Name',
    'category': 'Sales',
    'depends': ['base', 'sale_management'],
    'data': ['views/menu.xml', 'views/stock_views.xml', 'views/venta_views.xml', 'reports/venta_report.xml'],
    'installable': True,
    'auto_install': False,
}