# -*- coding: utf-8 -*-
# Part of Odoo. Modulo de peliculas realizado en ALMI
{
    'name': 'RopaAlmi',
    'version': '1.0',
    'depends' : ['base','contacts','mail'],
    'author' : 'Almi',
    'category': 'RopaAlmi',
    'website': '',
    'description': 'Modulo para  gestional Ropas',
}
